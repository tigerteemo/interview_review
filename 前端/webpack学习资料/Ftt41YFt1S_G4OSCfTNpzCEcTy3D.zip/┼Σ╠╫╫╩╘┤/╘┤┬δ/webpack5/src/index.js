import {one, two} from './common';

require('./style.css');

console.log(one(x, y));;